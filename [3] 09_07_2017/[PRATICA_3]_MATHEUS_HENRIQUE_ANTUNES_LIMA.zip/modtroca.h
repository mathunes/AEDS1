void troca1(int valor1, int valor);

void troca2(int *end_valor1, int *end_valor2);